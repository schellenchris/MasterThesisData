import subprocess
import os
import tempfile
import glob
import SimpleITK as sitk


class M2aiaOnlineHelper(object):
    def __init__(self, name : str, image : str, hostPort : str = "8855", workingDirectory : str = None, storageDir : str = None):
        self.name = name
        self.image = image
        self.hostPort = str(hostPort)
        if workingDirectory is None:
            self.workingDirectory = tempfile.mkdtemp()
        else:            
            self.workingDirectory = workingDirectory
        self.storageDir = storageDir
        self.containerId = None

    def __enter__(self):
        # kill if any process exist with this name
        command = ['docker', 'kill', self.name]
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if self.storageDir == None:
            command = ['docker', 'run', '-d', '--rm', '-p', self.hostPort +
                   ':80', '--name', self.name,
                   '-v', self.workingDirectory+':/data',
                   self.image]
        else:
            command = ['docker', 'run', '-d', '--rm', '-p', self.hostPort +
                   ':80', '--name', self.name,
                   '-v', self.workingDirectory+':/data',
                   '-v', self.storageDir+':/data/storage',
                   self.image]
        proc = subprocess.Popen(command, stdout=subprocess.PIPE)
        proc.stdout.read().decode("utf-8").strip()
        return self

    def write(self, data:dict):
        # temporary save images with given name
        for k, v in data.items():
            sitk.WriteImage(v, self.workingDirectory + "/" + k+".nrrd")

    def localipadress(self):
        import socket
        st = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:       
            st.connect(('10.255.255.255', 1))
            IP = st.getsockname()[0]
        except Exception:
            IP = '127.0.0.1'
        finally:
            st.close()
        return IP

    def show(self, data : dict):

        #write images to disk
        self.write(data)
        self.IP = self.localipadress()

        print("You can find your images @ ",
              'http://' + self.IP + ':'+self.hostPort)

        input("Press enter to proceed!")
        print("")

        # fix ownership> is there a better way
        if self.storageDir != None:
            command = ['docker', 'exec', self.name,
                   'chown', '-R', str(os.getuid())+':'+str(os.getuid()) , '/data/storage']
            proc = subprocess.run(command, stdout=subprocess.PIPE)

        # delete temprary files
        self.clear()

    def clear(self):
        files = glob.glob(self.workingDirectory + '/*.nrrd')
        for f in files:
            os.remove(f)

    def restart(self):
        # restart m2aia within the container
        command = ['docker', 'exec', self.name,
                   'supervisorctl', 'restart', 'm2aia']
        proc = subprocess.run(command, stdout=subprocess.PIPE)

    def __exit__(self, type, value, traceback):
        command = ['docker', 'kill', self.name]
        proc = subprocess.run(command, stdout=subprocess.PIPE)






