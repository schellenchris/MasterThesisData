import ctypes
import numpy as np
import SimpleITK as sitk


class M2aiaImageHelper(object):
    def __init__(self, lib, path, params, writeSampleParamFile=False):
        self.lib = lib
        self.lib.CreateImageHandle.argtypes = [
            ctypes.c_char_p, ctypes.c_char_p, ctypes.c_bool]
        self.lib.CreateImageHandle.restype = ctypes.c_void_p

        self.lib.DestroyImageHandle.argtypes = [ctypes.c_void_p]
        self.lib.DestroyImageHandle.restype = None

        self.lib.GetSize.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
        self.lib.GetSize.restype = None

        self.lib.GetSpacing.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        self.lib.GetSpacing.restype = None

        self.lib.GetXAxis.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        self.lib.GetXAxis.restype = None

        self.lib.GetImageArrayFloat64.argtypes = [
            ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.POINTER(ctypes.c_double)]
        self.lib.GetImageArrayFloat64.restype = None

        self.lib.GetImageArrayFloat32.argtypes = [
            ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.POINTER(ctypes.c_float)]
        self.lib.GetImageArrayFloat32.restype = None

        self.lib.GetSpectrumType.argtypes = [ctypes.c_void_p]
        self.lib.GetSpectrumType.restype = ctypes.c_uint32

        self.lib.GetSpectrumDepth.argtypes = [ctypes.c_void_p]
        self.lib.GetSpectrumDepth.restype = ctypes.c_uint32

        self.lib.GetMeanSpectrum.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        self.lib.GetMeanSpectrum.restype = None

        self.lib.GetMaxSpectrum.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        self.lib.GetMaxSpectrum.restype = None

        self.lib.GetYDataTypeSizeInBytes.argtype = [ctypes.c_void_p]
        self.lib.GetYDataTypeSizeInBytes.restype = ctypes.c_uint32

        self.lib.GetNumberOfSpectra.argtype = [ctypes.c_void_p]
        self.lib.GetNumberOfSpectra.restype = ctypes.c_uint32

        self.lib.GetSpectrum.argtype = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(
            ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.c_int]
        self.lib.GetSpectrum.restype = None

        self.path = path
        self.params = params
        self.writeParamsFile = writeSampleParamFile
        self.handle = None
        self.spectrum_type_id = None
        self.spectrum_types = {0: "None", 1: "ContinuousProfile",
                               2: "ProcessedProfile", 4: "ContinuousCentroid", 8: "ProcessedCentroid"}

        cPath = ctypes.create_string_buffer(self.path.encode())
        cParams = ctypes.create_string_buffer(self.params.encode())

        self.handle = self.lib.CreateImageHandle(
            cPath, cParams, self.writeParamsFile)

        if self.handle == None:
            raise ValueError(
                "The returned image handle is None. Check image- and parameter paths.\n\t[imzML] > " + self.path + "\n\t[params] > " + self.params)
        self.number_of_spectra = self.GetNumberOfSpectra()                               

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.lib.DestroyImageHandle(self.handle)
    
    def __delete__(self):
        self.lib.DestroyImageHandle(self.handle)

    def GetYDataType(self):
        size_in_bytes = self.lib.GetYDataTypeSizeInBytes(self.handle)
        if size_in_bytes == 4:
            return np.float32
        elif size_in_bytes == 8:
            return np.float64
        else:
            return None

    def GetShape(self):
        shape = np.zeros((3), dtype=np.int32)
        self.lib.GetSize(self.handle, shape.ctypes.data_as(
            ctypes.POINTER(ctypes.c_uint32)))
        return shape

    def GetSpacing(self):
        spacing = np.zeros((3), dtype=np.float64)
        self.lib.GetSpacing(self.handle, spacing.ctypes.data_as(
            ctypes.POINTER(ctypes.c_double)))
        return spacing

    def GetPixelPosition(self, id):
        pos = np.zeros((3), dtype=np.int32)
        self.lib.GetPixelPosition(self.handle, id, pos.ctypes.data_as(
            ctypes.POINTER(ctypes.c_uint32)))
        return pos

    def GetOrigin(self):
        origin = np.zeros((3), dtype=np.float64)
        self.lib.GetOrigin(self.handle, origin.ctypes.data_as(
            ctypes.POINTER(ctypes.c_double)))
        return origin

    def GetArray(self, center, tol, dtype=np.float32):
        xs = self.GetXAxis()
        
        if center < np.min(xs) or center > np.max(xs):
            raise ValueError("Center is out of x-axis range!")

        slice = np.zeros(self.GetShape()[::-1], dtype=dtype)
        if dtype == np.float32:
            self.lib.GetImageArrayFloat32(self.handle, center, tol, slice.ctypes.data_as(ctypes.POINTER(ctypes.c_float)))
        elif dtype == np.float64:
            self.lib.GetImageArrayFloat64(self.handle, center, tol, slice.ctypes.data_as(ctypes.POINTER(ctypes.c_double)))
        else:
            raise TypeError("Image pixel type is one of [np.float32, np.float64].")
        return slice

    def GetMeanSpectrum(self):
        mean_spectrum = np.zeros(self.GetSpectrumDepth(), dtype=np.float64)
        self.lib.GetMeanSpectrum(self.handle, mean_spectrum.ctypes.data_as(
            ctypes.POINTER(ctypes.c_double)))
        return mean_spectrum

    def GetMaxSpectrum(self):
        max_spectrum = np.zeros(self.GetSpectrumDepth(), dtype=np.float64)
        self.lib.GetMaxSpectrum(self.handle, max_spectrum.ctypes.data_as(
            ctypes.POINTER(ctypes.c_double)))
        return max_spectrum

    def GetSkylineSpectrum(self):
        pass

    def GetXAxis(self):
        x_axis = np.zeros(self.GetSpectrumDepth(), dtype=np.float64)
        self.lib.GetXAxis(self.handle, x_axis.ctypes.data_as(
            ctypes.POINTER(ctypes.c_double)))
        return x_axis

    def GetSpectrumDepth(self):
        depth = self.lib.GetSpectrumDepth(self.handle)
        if depth <= 0:
            raise RuntimeError("Spectrum depth can not be 0!")
        return depth

    def GetSpectrumType(self):
        self.spectrum_type_id = self.lib.GetSpectrumType(self.handle)
        return self.spectrum_types[self.spectrum_type_id]

    def GetImage(self, mz, tol, dtype=np.float32):
        array = self.GetArray(mz, tol,dtype)
        spacing = self.GetSpacing()
        origin = self.GetOrigin()
        I = sitk.GetImageFromArray(array)
        I.SetSpacing(spacing)
        I.SetOrigin(origin)
        return I

    def GetSpectrum(self, index):
        if index < 0 or index >= self.number_of_spectra:
            raise IndexError("Index "+ str(index) +" out of range of valid spectrum indices [0," + str(self.number_of_spectra - 1) + "] ")

        depth = self.GetSpectrumDepth()
        xs = np.zeros(depth, dtype=np.float32)
        ys = np.zeros(depth, dtype=np.float32)
        
        self.lib.GetSpectrum(self.handle, index, xs.ctypes.data_as(
              ctypes.POINTER(ctypes.c_float)), ys.ctypes.data_as(
              ctypes.POINTER(ctypes.c_float)))

        return [xs, ys]

    def GetNumberOfSpectra(self):
        return self.lib.GetNumberOfSpectra(self.handle)

    def SpectrumIterator(self):
        for i in range(self.number_of_spectra):
            xs,ys = self.GetSpectrum(i)
            yield i, xs, ys

    def SpectrumRandomBatchIterator(self, batch_size):
        while(True):
            ids = np.random.random_integers(0,self.number_of_spectra-1,batch_size)
            data = np.array([self.GetSpectrum(int(i))[1] for i in ids])
            yield data
        


# FILE_PATH = "/home/jtfc/HS/data/RawN-glycanMSI/png1 - no normalization.imzML"
# PARAM_PATH = "m2PeakPicking.txt.sample"

# with ImageHelper(FILE_PATH, PARAM_PATH) as image:
#     I = image.GetImage(mz=1000,tol=10)
#     sitk.WriteImage(I, "test.nrrd")
